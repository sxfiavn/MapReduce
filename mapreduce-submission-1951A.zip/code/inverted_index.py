#!/usr/bin/env python

import argparse
import json
import os
from pyspark import SparkContext


# Given a set of documents, an inverted index is a matching from each word to a
# list of document IDs of documents in which that word appears.

def parse_args():
    parser = argparse.ArgumentParser(
        description='MapReduce inverted index (Problem 1)')
    parser.add_argument('-d', help='path to data file',
                        default='./../data/books_small.json')
    parser.add_argument('-n', help='number of data slices', default=128)
    parser.add_argument('-o', help='path to output JSON', default='output')
    return parser.parse_args()

# Feel free to create more mappers and reducers


def mapper1(record):

    seen_words = []
    file = record[0]  # Get File
    content = record[1]  # Get Contents of the file

    indexes = []

    words_array = content.split(" ")  # Split by space
    for word in words_array:

        # creating list of words
        if word not in seen_words:
            seen_words.append(word)  # Add the word to the set
            indexes += [(word, [file])]  # add map Inverted index
        else:
            continue
    return indexes


def reducer1(a, b):
    return list(set(a+b))  # the use of a set: only unique words


def mapper2(record):
    # TODO
    pass


def reducer2(a, b):
    # TODO
    pass


# Do not modify except defining inverted_index_result
def main():
    args = parse_args()
    sc = SparkContext()

    with open(args.d, 'r') as infile:
        data = [json.loads(line) for line in infile]

    # TODO: build your pipeline
    # inverted_index_result =
    # note: use pyspark

    # reduce_sort = reduceByKey(reducer1).sortByKey(True).collect()
    inverted_index_result = sc.parallelize(data, args.n).flatMap(
        mapper1).reduceByKey(reducer1).collect()

    sc.stop()
    """
    output_inverted_index.json should be of the format -
    [
        [
            "dust",
            [
                "melville-moby_dick.txt"
            ]
        ],
        [
            "very",
            [
                "austen-emma.txt",
                "chesterton-thursday.txt",
                "edgeworth-parents.txt"
            ]
        ]
    ]

    """

    if not os.path.exists(args.o):
        os.makedirs(args.o)

    with open(args.o + '/output_inverted_index.json', 'w') as outfile:
        json.dump(inverted_index_result, outfile, indent=4)


if __name__ == '__main__':
    main()
