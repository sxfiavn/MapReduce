#!/usr/bin/env python

import argparse
import json
import os
from os.path import dirname, realpath

from pyspark import SparkContext


def parse_args():
    parser = argparse.ArgumentParser(description='MapReduce join (Problem 2)')
    parser.add_argument('-d', help='path to data file',
                        default='./../data/records.json')
    parser.add_argument('-n', help='number of data slices', default=128)
    parser.add_argument('-o', help='path to output JSON', default='output')
    return parser.parse_args()

# SQL Query
# SELECT *
# FROM Release, Disposal
# WHERE Release.CompanyID = Disposal.CompanyID

# Feel free to create more mappers and reducers.


def mapper(record):  # pass in json line
    # TODO
    return (record[2], [record])
    # mapping the Company Id to the record line.
    # Key is the company id

    # pass


def reducer1(a, b):
    # TODO
    return a + b  # on company id
    # pass


def mapper2(record):  # for each line
    # pass
    for entryA in record[1]:  # release
        for entryB in record[1]:
            yield entryA + entryB
# yield: returns a generator object to the one who calls the function which
#       contains yield, instead of simply returning a value.


def reducer2():
    # TODO
    pass


def filterer(record):  # Release.CompanyID = Disposal.CompanyID
    return ((record[0], record[17]) == ('rele', 'disp'))
    # we can access record[17] as we've joined them in reducer1.


def main():
    args = parse_args()
    sc = SparkContext()

    with open(args.d, 'r') as infile:
        data = [json.loads(line) for line in infile]

    # TODO: build your pipeline
    # join_result =
    join_result = sc.parallelize(data, 128).map(
        mapper).reduceByKey(reducer1).flatMap(mapper2).filter(filterer).collect()

    sc.stop()

    if not os.path.exists(args.o):
        os.makedirs(args.o)

    with open(args.o + '/output_join.json', 'w') as outfile:
        json.dump(join_result, outfile, indent=4)


if __name__ == '__main__':
    main()
